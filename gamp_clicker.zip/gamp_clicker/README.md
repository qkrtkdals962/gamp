# 🎯 3D 에임 트레이닝 게임 (통합 버전)

## ✨ 하나로 통합!

BABYLON.js 를 사용하기 때문에 
서버 실행이 필수

Node.js 설치가 되어있다는 가정하에
npm install 

npm run dev 를 통해 실행