# 🚀 Vite 서버로 실행하기

## ⚡ 빠른 시작

### 1. Node.js 설치 확인
```bash
node --version
npm --version
```

Node.js가 없다면: https://nodejs.org/ 에서 다운로드

---

### 2. 의존성 설치
```bash
npm install
```

---

### 3. 개발 서버 실행
```bash
npm run dev
```

→ 자동으로 브라우저가 열리고 `http://localhost:3000` 으로 실행됩니다! 🎉

---

## 📋 사용 가능한 명령어

### 개발 서버 (Hot Reload)
```bash
npm run dev
```
- 파일 수정 시 자동 새로고침
- 포트: 3000

### 프로덕션 빌드
```bash
npm run build
```
- `dist/` 폴더에 최적화된 파일 생성

### 빌드 미리보기
```bash
npm run preview
```
- 빌드된 파일을 로컬에서 테스트

---

## 🆚 Python vs Vite 비교

### Python (이전)
```bash
python -m http.server 8000
# http://localhost:8000/index.html
```

### Vite (현재)
```bash
npm run dev
# http://localhost:3000  (자동 오픈!)
```

---

## ✨ Vite의 장점

1. **⚡ 초고속 시작**: 즉시 실행
2. **🔥 Hot Module Replacement**: 수정 시 자동 새로고침
3. **📦 자동 빌드**: 프로덕션 배포 쉬움
4. **🎯 최적화**: 자동으로 코드 최적화
5. **🌐 현대적**: ES Modules 기본 지원

---

## 🔧 포트 변경

`vite.config.js` 파일에서:
```javascript
server: {
  port: 3000,  // 원하는 포트로 변경
}
```

---

## 📁 프로젝트 구조

```
gamp_improved/
├── index.html          # 메인 HTML
├── style.css           # 스타일
├── js/                 # JavaScript 파일들
├── package.json        # npm 설정
├── vite.config.js      # Vite 설정
└── README_VITE.md      # 이 파일
```

---

## 🐛 문제 해결

### "npm: command not found"
→ Node.js를 설치하세요

### 포트가 이미 사용 중
→ `vite.config.js`에서 포트 변경

### 브라우저가 자동으로 안 열림
→ 수동으로 `http://localhost:3000` 접속

---

## 🎮 게임 즐기기

1. `npm run dev` 실행
2. 브라우저 자동 오픈
3. 게임 선택하고 플레이!

---

## 📦 배포하기

### 빌드
```bash
npm run build
```

### 결과물
`dist/` 폴더의 파일들을 서버에 업로드하면 됩니다!

---

**이제 Python 대신 `npm run dev` 만 입력하면 됩니다!** 🚀
