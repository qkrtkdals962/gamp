(function(){
    // 캔버스 요소 참조
    const canvas2D = document.getElementById('gameCanvas');
    const canvas3D = document.getElementById('renderCanvas3D');
    
    const hud = document.getElementById('hud');
    const scoreEl = document.getElementById('score');
    const bestEl = document.getElementById('best');
    const timerWrap = document.getElementById('timerWrap');
    const timerEl = document.getElementById('timer');
    const overWrap = document.getElementById('gameOver');
    const finalScore = document.getElementById('finalScore');
    const finalBest = document.getElementById('finalBest');
    const retryBtn = document.getElementById('retryBtn');
    const menuBtn = document.getElementById('menuBtn');

    // 에임 트레이너 전용 통계 요소
    const aimStatsEl = document.getElementById('aimStats');
    const accuracyEl = document.getElementById('accuracy');
    const comboEl = document.getElementById('combo');
    const hitsEl = document.getElementById('hits');
    const extraStatsEl = document.getElementById('extraStats');
    const finalAccuracy = document.getElementById('finalAccuracy');
    const finalMaxCombo = document.getElementById('finalMaxCombo');
    const finalShots = document.getElementById('finalShots');
    const finalHits = document.getElementById('finalHits');
    const gameOverTitle = document.getElementById('gameOverTitle');
    const gameOverMessage = document.getElementById('gameOverMessage');

    // 조준점 오버레이
    const crosshairEl = document.getElementById('crosshair');
    
    // 에임 트레이너 시작 화면
    const aimTrainerStartEl = document.getElementById('aimTrainerStart');
    const aimTrainerPlayBtn = document.getElementById('aimTrainerPlayBtn');
    
    // 뒤로가기 버튼
    const backButton = document.getElementById('backButton');

    const menu = document.getElementById('menu');
    const cards = menu.querySelectorAll('.card');

    // 2D 엔진 초기화는 기존 2D 캔버스를 사용합니다.
    const E = window.Engine; E.init(canvas2D); 

    const mgr = new window.SceneManager();
    
    // Babylon.js 관련 전역 변수 (3D 게임에만 사용)
    let babylonEngine = null;
    let babylonScene = null;
    
    function GameScene(gameKey){
        this.key = gameKey; 
        this.game = null; 
        this.bestKey = 'best_' + gameKey;
        this.is3D = (gameKey === 'clicker'); // 클리커만 3D로 지정
        this.isAimTrainer = (gameKey === 'clicker'); // 에임 트레이너 플래그
        this.gameOverTriggered = false; // 게임오버 중복 방지
        this.isReady = !this.isAimTrainer; // 에임 트레이너가 아니면 바로 시작
        this.gameStarted = false; // 게임 시작 여부
    }
    
    // 씬 진입 시 (게임 시작 시)
    GameScene.prototype.onEnter = function(){
        const map = { runner: window.RunnerGame, catcher: window.CatcherGame, clicker: window.ClickerGame };
        
        // 🟢 [수정 1] 이전에 실행되던 Babylon 렌더링 루프를 먼저 중지합니다.
        if (babylonEngine) {
            babylonEngine.stopRenderLoop();
        }

        // 🎯 에임 트레이너인 경우 시작 화면 표시
        if (this.isAimTrainer) {
            // 시작 화면 표시
            if (aimTrainerStartEl) {
                aimTrainerStartEl.classList.remove('hidden');
                aimTrainerStartEl.classList.add('show');
            }
            
            // 메뉴 숨기기
            menu.classList.remove('show');
            
            // 캔버스 완전히 숨기기
            canvas2D.style.display = 'none';
            canvas3D.style.display = 'none';
            
            // 배경 어둡게
            document.body.style.background = '#0a0a0f';
            
            // PLAY 버튼 클릭 이벤트
            if (aimTrainerPlayBtn) {
                aimTrainerPlayBtn.onclick = () => {
                    console.log("🎮 PLAY button clicked!");
                    this.startAimTrainerGame();
                };
            }
            
            // 🔙 뒤로가기 버튼 표시 (시작 화면에서도)
            if (backButton) {
                backButton.classList.add('show');
            }
            
            return; // 여기서 종료하고 PLAY 버튼을 기다림
        }

        // 캔버스 가시성 전환
        if (this.is3D) {
            canvas2D.style.display = 'none';
            canvas3D.style.display = 'block';
            
            // 🎨 클리커 선택 시 배경을 어둡게 변경
            document.body.style.background = '#0a0a0f';
            
            // 🖱️ 에임 트레이너에서만 기본 커서 숨기기
            document.body.classList.add('aim-trainer-mode');
            
            // 🎯 에임 트레이너 통계 및 조준점 표시
            if (this.isAimTrainer && aimStatsEl && crosshairEl) {
                aimStatsEl.classList.add('show');
                crosshairEl.classList.add('show');
                // 십자선은 CSS로 중앙에 고정되어 있음
            }
            
            // 🟢 Babylon.js 엔진 및 씬 초기화
            if (!babylonEngine) {
                babylonEngine = new BABYLON.Engine(canvas3D, true);
                // 윈도우 크기 변경 시 3D 캔버스 크기 조정
                window.addEventListener("resize", function () { babylonEngine.resize(); });
            }
            // clicker.js에 Babylon 엔진과 캔버스를 전달하여 씬 생성 요청
            this.game = new map[this.key]();
            babylonScene = this.game.init3D(babylonEngine, canvas3D); 
            
            // 🟢 [수정 2] 3D 게임일 때만 렌더링 루프를 시작합니다. (빈 화면 해결 핵심)
            babylonEngine.runRenderLoop(function () {
                if (babylonScene) babylonScene.render();
            });
            
        } else {
            canvas2D.style.display = 'block';
            canvas3D.style.display = 'none';
            
            // 🎨 2D 게임 선택 시 배경을 노란색으로 유지
            document.body.style.background = '#f7e08b';
            
            // 🎯 에임 트레이너 UI 숨기기
            if (aimStatsEl && crosshairEl) {
                aimStatsEl.classList.remove('show');
                crosshairEl.classList.remove('show');
            }
            
            // 2D 게임 초기화
            this.game = new map[this.key]();
            this.game.init();
        }

        menu.classList.remove('show');
        hud.classList.remove('hidden');
        overWrap.classList.add('hidden');
        
        // ⏱️ 타이머 표시 (에임 트레이너에서만)
        if (this.key === 'clicker') {
            timerWrap.classList.remove('hidden');
            timerWrap.classList.remove('warning');
        } else {
            timerWrap.classList.add('hidden');
        }
        
        // 🔙 뒤로가기 버튼 표시
        if (backButton) {
            backButton.classList.add('show');
        }
        
        // 3D 게임일 때 캔버스 클릭 가능하도록 확실히 설정
        if (this.is3D) {
            canvas3D.style.pointerEvents = 'auto';
        }

        // 커서 설정
        const targetCanvas = this.is3D ? canvas3D : canvas2D;
        const otherCanvas = this.is3D ? canvas2D : canvas3D;
        
        targetCanvas.style.cursor = (this.key === 'clicker' && this.is3D) ? 'none' : 'default';
        otherCanvas.style.cursor = 'default';
    };
    
    // 에임 트레이너 게임 실제 시작
    GameScene.prototype.startAimTrainerGame = function() {
        const map = { clicker: window.ClickerGame };
        
        console.log("🎯 Starting Aim Trainer Game...");
        
        // 시작 화면 숨기기
        if (aimTrainerStartEl) {
            aimTrainerStartEl.classList.remove('show');
            aimTrainerStartEl.classList.add('hidden');
        }
        
        this.isReady = true;
        this.gameStarted = true;
        
        // 캔버스 가시성 전환
        canvas2D.style.display = 'none';
        canvas3D.style.display = 'block';
        
        // 🎨 배경을 어둡게 변경
        document.body.style.background = '#0a0a0f';
        
        // 🖱️ 에임 트레이너에서만 기본 커서 숨기기
        document.body.classList.add('aim-trainer-mode');
        
        // 🎯 에임 트레이너 통계 및 조준점 표시
        if (aimStatsEl && crosshairEl) {
            aimStatsEl.classList.add('show');
            crosshairEl.classList.add('show');
            // 십자선은 CSS로 중앙에 고정되어 있음
        }
        
        // 🟢 Babylon.js 엔진 및 씬 초기화
        if (!babylonEngine) {
            babylonEngine = new BABYLON.Engine(canvas3D, true);
            // 윈도우 크기 변경 시 3D 캔버스 크기 조정
            window.addEventListener("resize", function () { babylonEngine.resize(); });
        }
        
        // clicker.js에 Babylon 엔진과 캔버스를 전달하여 씬 생성 요청
        this.game = new map['clicker']();
        babylonScene = this.game.init3D(babylonEngine, canvas3D); 
        
        // 🟢 3D 게임 렌더링 루프 시작
        babylonEngine.runRenderLoop(function () {
            if (babylonScene) babylonScene.render();
        });
        
        // 3D 게임일 때 캔버스 클릭 가능하도록 확실히 설정
        canvas3D.style.pointerEvents = 'auto';
        canvas3D.style.cursor = 'none';
        
        // HUD 표시
        hud.classList.remove('hidden');
        overWrap.classList.add('hidden');
        
        // ⏱️ 타이머 표시
        timerWrap.classList.remove('hidden');
        timerWrap.classList.remove('warning');
        
        console.log("✅ Aim Trainer Game Started!");
    };
    
    // 씬 종료 시 (메뉴 복귀 등)
    GameScene.prototype.onExit = function(){
        // 🟢 [수정 3] 씬을 떠날 때 Babylon 렌더링 루프를 중지합니다.
        if (babylonEngine) {
            babylonEngine.stopRenderLoop();
        }
        
        // 🎯 에임 트레이너 시작 화면 숨기기
        if (aimTrainerStartEl) {
            aimTrainerStartEl.classList.remove('show');
            aimTrainerStartEl.classList.add('hidden');
        }
        
        // 🎯 마우스 추적 이벤트 제거
        if (this.mouseMoveHandler) {
            document.removeEventListener('mousemove', this.mouseMoveHandler);
            this.mouseMoveHandler = null;
        }
        
        // 🖱️ 커서 복구
        document.body.classList.remove('aim-trainer-mode');
        
        canvas2D.style.cursor = 'default';
        canvas3D.style.cursor = 'default';
        
        if (this.is3D && babylonScene) {
            // 필요 시 씬 자원 정리
            // babylonScene.dispose(); 
        }
    };
    
    GameScene.prototype.update = function(dt){
        // 에임 트레이너가 아직 시작되지 않았으면 업데이트 하지 않음
        if (this.isAimTrainer && !this.gameStarted) {
            return;
        }
        
        // R키는 제거 - 뒤로가기 버튼만 사용

        // 3D 게임은 Babylon.js의 렌더 루프를 따르므로, 여기서 업데이트 로직만 실행합니다.
        // 3D/2D 모두 this.game.update(dt) 호출은 유지
        this.game.update(dt); 
        
        scoreEl.textContent = this.game.getScore();
        const best = Number(localStorage.getItem(this.bestKey) || 0);
        bestEl.textContent = best;
        
        // 타이머 업데이트 및 경고 표시
        if(this.key === 'clicker') {
            const timeLeft = Math.ceil(this.game.time);
            timerEl.textContent = timeLeft;
            
            // 10초 이하일 때 경고 애니메이션
            if (timeLeft <= 10 && timeLeft > 0) {
                timerWrap.classList.add('warning');
            } else {
                timerWrap.classList.remove('warning');
            }
        }
        
        // 🎯 에임 트레이너 실시간 통계 업데이트
        if (this.isAimTrainer && this.game.getStats) {
            const stats = this.game.getStats();
            if (accuracyEl) accuracyEl.textContent = stats.accuracy + '%';
            if (comboEl) {
                comboEl.textContent = '×' + stats.combo;
                // 콤보에 따라 색상 변경
                if (stats.combo >= 5) {
                    comboEl.style.color = '#ff0066';
                    comboEl.style.fontSize = '1.3rem';
                } else if (stats.combo >= 3) {
                    comboEl.style.color = '#ff6600';
                    comboEl.style.fontSize = '1.2rem';
                } else {
                    comboEl.style.color = '#ff3366';
                    comboEl.style.fontSize = '1.1rem';
                }
            }
            if (hitsEl) hitsEl.textContent = stats.hits + '/' + stats.shots;
        }

        if(this.game.isOver && !this.gameOverTriggered){
            this.gameOverTriggered = true; // 플래그 설정
            
            console.log("🎮 Game Over triggered for:", this.key);
            
            // 🖱️ 에임 트레이너 게임오버 시 커서 복구
            if (this.isAimTrainer) {
                document.body.classList.remove('aim-trainer-mode');
                canvas3D.style.cursor = 'default';
                
                // 조준점 숨기기
                if (crosshairEl) {
                    crosshairEl.classList.remove('show');
                }
            }
            
            // 게임 오버 로직 (2D/3D 공통)
            const sc = this.game.getScore();
            if(sc > best) localStorage.setItem(this.bestKey, String(sc));
            finalScore.textContent = sc;
            finalBest.textContent = Math.max(sc, best);
            
            // 🎯 에임 트레이너 최종 통계 표시
            if (this.isAimTrainer && this.game.getStats && extraStatsEl) {
                const stats = this.game.getStats();
                extraStatsEl.classList.add('show');
                
                // 게임오버 타이틀 및 메시지
                if (gameOverTitle) gameOverTitle.textContent = '시간 종료!';
                if (gameOverMessage) gameOverMessage.textContent = '30초 동안의 결과입니다';
                
                // 통계 표시
                if (finalAccuracy) finalAccuracy.textContent = stats.accuracy + '%';
                if (finalMaxCombo) finalMaxCombo.textContent = '×' + stats.maxCombo;
                if (finalShots) finalShots.textContent = stats.shots + '발';
                if (finalHits) finalHits.textContent = stats.hits + '발';
                
                // 평가 메시지
                let grade = '';
                if (stats.accuracy >= 80) grade = '🏆 완벽합니다!';
                else if (stats.accuracy >= 60) grade = '🎯 훌륭해요!';
                else if (stats.accuracy >= 40) grade = '👍 좋아요!';
                else if (stats.accuracy >= 20) grade = '📈 연습이 필요해요';
                else grade = '💪 다시 도전해보세요!';
                
                if (gameOverMessage) gameOverMessage.textContent = `30초 동안의 결과 - ${grade}`;
            } else {
                if (extraStatsEl) extraStatsEl.classList.remove('show');
                if (gameOverTitle) gameOverTitle.textContent = '게임 오버';
                if (gameOverMessage) gameOverMessage.textContent = '';
            }
            
            overWrap.classList.remove('hidden');
            
            console.log("✅ Game Over screen shown");
            
            // 리트라이 버튼은 현재 씬을 다시 설정하여 onEnter를 다시 호출하도록 함
            retryBtn.onclick = ()=>{ 
                console.log("🔄 Retry clicked");
                mgr.set(new GameScene(this.key)); // 씬 전체를 다시 로드
            };
            menuBtn.onclick = ()=>{ 
                console.log("🏠 Menu clicked");
                mgr.set(new MenuScene()); 
            };
        }
    };
    
    GameScene.prototype.draw = function(){ 
        if (!this.is3D) {
            // 2D 게임만 draw()를 호출합니다.
            this.game.draw();
        } 
    };

    function MenuScene(){}
    MenuScene.prototype.onEnter = function(){
        // 🟢 [수정 4] 메뉴 진입 시 Babylon 렌더링 루프를 중지합니다.
        if (babylonEngine) {
            babylonEngine.stopRenderLoop();
        }
        
        hud.classList.add('hidden');
        menu.classList.add('show');
        
        // 🎮 게임오버 화면 확실히 숨기기
        overWrap.classList.add('hidden');
        
        // ⏱️ 타이머 숨기기 (중요!)
        if (timerWrap) {
            timerWrap.classList.add('hidden');
            timerWrap.classList.remove('warning');
        }
        
        // 🔙 뒤로가기 버튼 숨김
        if (backButton) {
            backButton.classList.remove('show');
        }
        
        // 🎯 에임 트레이너 UI 숨기기
        if (aimStatsEl && crosshairEl) {
            aimStatsEl.classList.remove('show');
            crosshairEl.classList.remove('show');
        }
        
        // 🎨 메뉴로 돌아갈 때 배경을 노란색으로 복구
        document.body.style.background = '#f7e08b';
        
        // 🖱️ 기본 커서 복구
        document.body.classList.remove('aim-trainer-mode');
        
        // 캔버스 가시성 정리
        canvas2D.style.display = 'block';
        canvas3D.style.display = 'none';
        canvas2D.style.cursor = 'default';
    };
    MenuScene.prototype.update = function(){ };
    MenuScene.prototype.draw = function(){ E.clear('#fff6cf'); E.drawText('게임을 선택하세요', 240, 340, '#3a2f0b', 18, 'center'); };

    cards.forEach(btn=>{
        btn.addEventListener('click', ()=>{
            const key = btn.getAttribute('data-game');
            mgr.set(new GameScene(key));
        });
    });
    
    // 🔙 뒤로가기 버튼 클릭 이벤트
    if (backButton) {
        backButton.addEventListener('click', ()=>{
            mgr.set(new MenuScene());
        });
    }

    mgr.set(new MenuScene());

    // 2D 게임 루프는 항상 실행
    E.loop((dt)=>{
        mgr.update(dt);
        mgr.draw();
        // 3D 렌더링은 위에 runRenderLoop/stopRenderLoop에서만 제어됩니다.
    });

})();