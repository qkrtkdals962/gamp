(function(){
  const E = window.Engine;

  function CatcherGame(){
    this.player = { x: E.width/2-30, y: E.height-90, w: 60, h: 20, speed: 360 };
    this.items = [];
    this.spawn = 0; 
    this.time = 0; 
    this.over = false; 
    this.score = 0; 
    this.lives = 3;
  }
  
  CatcherGame.prototype.init = function(){ 
    this.items.length = 0; 
    this.spawn = 0; 
    this.time = 0; 
    this.over = false; 
    this.score = 0; 
    this.lives = 3; 
  };
  
  CatcherGame.prototype.update = function(dt){ 
    if(this.over) return; 
    
    this.time += dt;
    
    // 플레이어 이동
    let dir = 0; 
    if(E.keys.has('arrowleft') || E.keys.has('a')) dir -= 1; 
    if(E.keys.has('arrowright') || E.keys.has('d')) dir += 1;
    
    if(E.mouse.down){
      const mx = E.mouse.x; 
      this.player.x = E.clamp(mx - this.player.w/2, 0, E.width - this.player.w);
    } else { 
      this.player.x = E.clamp(this.player.x + dir * this.player.speed * dt, 0, E.width - this.player.w); 
    }
    
    // 아이템 생성
    this.spawn -= dt; 
    if(this.spawn <= 0){ 
      this.spawn = E.rnd(0.4, 0.9); 
      const bad = Math.random() < 0.22; 
      this.items.push({
        x: E.rnd(10, E.width - 10), 
        y: -20, 
        r: 12, 
        vy: E.rnd(120, 220), 
        bad: bad,
        caught: false
      }); 
    }
    
    // 아이템 이동 및 충돌 체크
    for(const it of this.items){ 
      it.y += it.vy * dt; 
      
      const box = {x: this.player.x, y: this.player.y, w: this.player.w, h: this.player.h}; 
      const b = {x: it.x - it.r, y: it.y - it.r, w: it.r * 2, h: it.r * 2};
      
      if(E.aabb(box, b) && !it.caught){
        it.caught = true;
        if(it.bad){ 
          this.lives--; 
        } else { 
          this.score += 10; 
        }
        it.remove = true;
      }
    }
    
    // 화면 밖으로 나간 아이템 처리
    for(const it of this.items){ 
      if(it.y > E.height + 30) {
        // 좋은 아이템(별)을 못 받으면 목숨 감소
        if(!it.bad && !it.caught) {
          this.lives--;
          console.log("⭐ 별을 놓쳤습니다! 남은 목숨:", this.lives);
        }
        it.remove = true; 
      }
    }
    
    this.items = this.items.filter(i => !i.remove);
    
    // 게임오버 체크 (목숨이 0 이하일 때)
    if(this.lives <= 0) {
      this.over = true;
      this.lives = 0; // 음수 방지
      console.log("💀 캐쳐 게임 오버! 최종 점수:", this.score);
    }
  };
  
  CatcherGame.prototype.draw = function(){ 
    const c = E.ctx; 
    E.clear('#fff7d9');
    
    // 배경 패턴
    c.fillStyle = '#f0deb0'; 
    for(let y = 20; y < E.height; y += 40){ 
      for(let x = 20; x < E.width; x += 40){ 
        c.fillRect(x, y, 3, 3); 
      }
    }
    
    // 플레이어
    E.drawRoundRect(this.player.x, this.player.y, this.player.w, this.player.h, 6, '#9bd1ff', '#246a96');
    
    // 아이템 (별/폭탄)
    for(const it of this.items){ 
      c.beginPath(); 
      c.fillStyle = it.bad ? '#ff6961' : '#ffd166'; 
      c.arc(it.x, it.y, it.r, 0, Math.PI * 2); 
      c.fill(); 
    }
    
    // UI
    E.drawText(`캐쳐: 방향키/드래그`, 12, 8, '#5a4a16', 14);
    E.drawText(`목숨 ${this.lives}`, E.width - 12, 8, '#a12d2d', 14, 'right');
  };
  
  CatcherGame.prototype.getScore = function(){ 
    return this.score; 
  };
  
  Object.defineProperty(CatcherGame.prototype, 'isOver', { 
    get(){ return this.over; }
  });

  window.CatcherGame = CatcherGame;
})();
