(function(){
  const E = window.Engine;

  function RunnerGame(){
    this.player = { x: 80, y: 600, w: 32, h: 42, vy: 0, onGround: true };
    this.groundY = 640;
    this.gravity = 1400;
    this.jumpV = -580;
    this.speed = 240;
    this.spawn = 0;
    this.obstacles = [];
    this.time = 0;
    this.over = false;
  }
  RunnerGame.prototype.init = function(){ this.obstacles.length=0; this.time=0; this.over=false; this.player.y=this.groundY-this.player.h; this.player.vy=0; this.player.onGround=true; this.spawn=0; };
  RunnerGame.prototype.control = function(){
    if(this.player.onGround){
      if(E.keys.has(' ')||E.keys.has('arrowup')||E.mouse.down){ this.player.vy = this.jumpV; this.player.onGround = false; }
    }
  };
  RunnerGame.prototype.update = function(dt){ if(this.over) return; this.time += dt; this.control();
    this.player.vy += this.gravity*dt; this.player.y += this.player.vy*dt;
    if(this.player.y + this.player.h >= this.groundY){ this.player.y = this.groundY - this.player.h; this.player.vy = 0; this.player.onGround = true; }
    this.spawn -= dt; if(this.spawn<=0){ this.spawn = E.rnd(0.8,1.4); const h=E.rnd(28,46); this.obstacles.push({ x: E.width+40, y: this.groundY-h, w:E.rnd(20,32), h}); }
    for(const o of this.obstacles){ o.x -= this.speed*dt; if(E.aabb({x:this.player.x,y:this.player.y,w:this.player.w,h:this.player.h},o)){ this.over = true; }}
    this.obstacles = this.obstacles.filter(o=>o.x>-60);
  };
  RunnerGame.prototype.draw = function(){ const c = E.ctx; E.clear();
    c.fillStyle = '#f3d96d'; for(let i=0;i<12;i++){ c.fillRect(0, i*60+20, E.width, 6); }
    c.fillStyle = '#e2c546'; c.fillRect(0,this.groundY, E.width, 6);
    for(const o of this.obstacles){ E.drawRoundRect(o.x,o.y,o.w,o.h,6,'#94c973','#3a7a2a'); }
    E.drawRoundRect(this.player.x,this.player.y,this.player.w,this.player.h,8,'#ffb570','#ce7a2a');
    E.drawText('러너: 스페이스/터치로 점프', 12, 8, '#5a4a16', 14);
  };
  RunnerGame.prototype.getScore = function(){ return Math.floor(this.time*10); };
  Object.defineProperty(RunnerGame.prototype,'isOver',{ get(){ return this.over; }});

  window.RunnerGame = RunnerGame;
})();