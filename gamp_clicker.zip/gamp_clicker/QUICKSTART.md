# 🚀 빠른 시작 가이드

## 1️⃣ 파일 다운로드
이 폴더의 모든 파일을 컴퓨터에 다운로드하세요.

## 2️⃣ 로컬 서버 실행

### 방법 A: Python이 설치되어 있다면
```bash
# 터미널에서 파일이 있는 폴더로 이동 후
python -m http.server 8000
```

### 방법 B: Node.js가 설치되어 있다면
```bash
npx serve
```

### 방법 C: VS Code 사용자
1. VS Code로 폴더 열기
2. "Live Server" 확장 설치
3. HTML 파일에서 우클릭 → "Open with Live Server"

### 방법 D: 간단한 웹 서버
- [Web Server for Chrome](https://chrome.google.com/webstore/detail/web-server-for-chrome/ofhbbkphhbklhfoeikjpcbhemlocgigb) 확장 프로그램 사용

## 3️⃣ 게임 실행
브라우저에서 `http://localhost:8000/index_improved.html` 접속

## 4️⃣ 플레이
"🎯 에임 트레이너" 카드를 클릭하고 즐기세요!

---

## ❗ 주의사항
- **파일을 직접 더블클릭하여 열면 안됩니다!**
  - 이유: Babylon.js는 보안상 로컬 서버에서만 작동합니다
  - `file://` 프로토콜이 아닌 `http://` 필요

- **최신 브라우저 사용 권장**
  - Chrome, Firefox, Edge, Safari 등
  - WebGL 지원 필수

---

## 🎮 게임 선택
폴더에는 3개의 파일이 있습니다:

1. **index_improved.html** ⭐ (추천!)
   - 개선된 3D 에임 트레이너
   - 최신 기능 모두 포함

2. **index.html**
   - 기본 버전 (비교용)

둘 다 실행해보고 차이를 느껴보세요!
